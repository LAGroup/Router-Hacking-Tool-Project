# Returns a string, containing N spaces

def space_gen n

	string = String.new
	n.times do 
		string = string + " "
	end

	return string
end


