if !system("sudo ruby main.rb")
	abort("\nFatal Error: Main program could not run properly!")
end
