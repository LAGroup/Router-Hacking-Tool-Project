#Monitoring Starter

`sudo airmon-ng`
`sudo airmon-ng start wlan0`

puts "Successfully opened \n\n"

#`sudo airodump-ng mon0`


