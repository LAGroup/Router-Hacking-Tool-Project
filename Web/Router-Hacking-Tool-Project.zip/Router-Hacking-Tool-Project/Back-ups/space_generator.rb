#Generates N new lines

def space_generator n

	i = 0
	while i < n
		puts
		i += 1
	end

end


